/**
 * server.js
 * ─────────────────────────────────────────────────────────────
 * Whop → Shopify Order Sync Backend
 * - Receives orders from the Whop checkout page
 * - Creates orders in Shopify via Admin API
 * - Validates Whop webhooks with HMAC verification
 * ─────────────────────────────────────────────────────────────
 * Setup:
 *   npm install
 *   node server.js
 *
 * Environment variables (create a .env file):
 *   SHOPIFY_STORE=les-kicks-du-quebec
 *   SHOPIFY_ADMIN_TOKEN=shpat_xxxxxxxxxxxxxxxxxxxx
 *   WHOP_API_KEY=your_whop_api_key
 *   WHOP_WEBHOOK_SECRET=your_whop_webhook_secret
 *   PORT=3000
 */

require('dotenv').config();
const express  = require('express');
const cors     = require('cors');
const crypto   = require('crypto');
const fetch    = (...args) => import('node-fetch').then(({ default: f }) => f(...args));

const app  = express();
const PORT = process.env.PORT || 3000;

// ─── MIDDLEWARE ──────────────────────────────────────────────────────────────
app.use(cors({ origin: '*' }));
app.use(express.json());
app.use(express.static('.'));   // serve index.html, style.css, checkout.js

// ─── HELPERS ─────────────────────────────────────────────────────────────────
const SHOPIFY_BASE = `https://${process.env.SHOPIFY_STORE}.myshopify.com/admin/api/2024-01`;
const SHOPIFY_HEADERS = {
  'Content-Type':              'application/json',
  'X-Shopify-Access-Token':    process.env.SHOPIFY_ADMIN_TOKEN,
};

/**
 * Verify Whop webhook HMAC signature
 */
function verifyWhopWebhook(req) {
  const sig    = req.headers['x-whop-signature'] || '';
  const secret = process.env.WHOP_WEBHOOK_SECRET || '';
  const body   = JSON.stringify(req.body);
  const expected = crypto
    .createHmac('sha256', secret)
    .update(body, 'utf8')
    .digest('hex');
  return crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected));
}

/**
 * Map Whop checkout payload → Shopify order payload
 */
function mapToShopifyOrder(payload) {
  return {
    order: {
      email:              payload.email,
      phone:              payload.phone || '',
      financial_status:   'paid',
      fulfillment_status: null,
      currency:           payload.currency || 'CAD',
      total_price:        payload.total_price,
      subtotal_price:     payload.subtotal_price,
      source_name:        'whop',
      note:               payload.note || 'Placed via Whop checkout',
      tags:               payload.tags || 'whop',
      send_receipt:       true,
      send_fulfillment_receipt: true,

      line_items: (payload.line_items || []).map(item => ({
        title:         item.title,
        variant_title: item.variant_title || '',
        quantity:      item.quantity,
        price:         item.price,
        sku:           item.sku || '',
        requires_shipping: true,
        taxable:       true,
      })),

      shipping_lines: (payload.shipping_lines || []).map(line => ({
        title: line.title,
        price: line.price,
        code:  line.code || 'standard',
      })),

      discount_codes: payload.discount_codes || [],

      shipping_address: {
        first_name: payload.shipping_address?.first_name || '',
        last_name:  payload.shipping_address?.last_name  || '',
        address1:   payload.shipping_address?.address1   || '',
        address2:   payload.shipping_address?.address2   || '',
        city:       payload.shipping_address?.city        || '',
        province:   payload.shipping_address?.province    || '',
        zip:        payload.shipping_address?.zip         || '',
        country:    payload.shipping_address?.country     || 'CA',
        phone:      payload.shipping_address?.phone       || '',
      },

      billing_address: {
        first_name: payload.billing_address?.first_name || payload.shipping_address?.first_name || '',
        last_name:  payload.billing_address?.last_name  || payload.shipping_address?.last_name  || '',
        address1:   payload.billing_address?.address1   || payload.shipping_address?.address1   || '',
        address2:   payload.billing_address?.address2   || payload.shipping_address?.address2   || '',
        city:       payload.billing_address?.city        || payload.shipping_address?.city       || '',
        province:   payload.billing_address?.province    || payload.shipping_address?.province   || '',
        zip:        payload.billing_address?.zip         || payload.shipping_address?.zip        || '',
        country:    payload.billing_address?.country     || payload.shipping_address?.country    || 'CA',
      },

      customer: {
        email:      payload.email,
        first_name: payload.shipping_address?.first_name || '',
        last_name:  payload.shipping_address?.last_name  || '',
        phone:      payload.phone || '',
        accepts_marketing: true,
      },

      transactions: [{
        kind:   'sale',
        status: 'success',
        amount: payload.total_price,
        gateway: payload.payment_gateway || 'whop',
      }],
    }
  };
}

// ─── ROUTES ──────────────────────────────────────────────────────────────────

/**
 * POST /api/sync-order
 * Called by the checkout page when a customer completes payment on Whop.
 * Creates a draft/confirmed order in Shopify.
 */
app.post('/api/sync-order', async (req, res) => {
  try {
    const payload = req.body;
    console.log(`\n📦 Incoming order from Whop: ${payload.order_name}`);

    // Map payload to Shopify order format
    const shopifyPayload = mapToShopifyOrder(payload);
    console.log('📝 Shopify payload:', JSON.stringify(shopifyPayload, null, 2));

    // Create order via Shopify Admin API
    const shopifyRes = await fetch(`${SHOPIFY_BASE}/orders.json`, {
      method:  'POST',
      headers: SHOPIFY_HEADERS,
      body:    JSON.stringify(shopifyPayload),
    });

    if (!shopifyRes.ok) {
      const errBody = await shopifyRes.text();
      console.error('❌ Shopify API error:', shopifyRes.status, errBody);
      return res.status(502).json({ error: 'Shopify API error', details: errBody });
    }

    const shopifyData = await shopifyRes.json();
    const shopifyOrderId = shopifyData.order?.id;
    const shopifyOrderNum = shopifyData.order?.name;

    console.log(`✅ Order synced to Shopify! ID: ${shopifyOrderId} | #${shopifyOrderNum}`);

    return res.status(200).json({
      success:         true,
      whop_order:      payload.order_name,
      shopify_order_id: shopifyOrderId,
      shopify_order_num: shopifyOrderNum,
    });

  } catch (err) {
    console.error('❌ Server error:', err);
    return res.status(500).json({ error: 'Internal server error', message: err.message });
  }
});

/**
 * POST /api/whop-webhook
 * Receives Whop platform webhooks (e.g. payment.completed, membership.created)
 * and syncs to Shopify automatically.
 */
app.post('/api/whop-webhook', async (req, res) => {
  // Verify HMAC (skip if no secret set yet)
  if (process.env.WHOP_WEBHOOK_SECRET) {
    try {
      if (!verifyWhopWebhook(req)) {
        console.warn('⚠️  Invalid Whop webhook signature');
        return res.status(401).json({ error: 'Unauthorized' });
      }
    } catch (err) {
      console.warn('⚠️  Webhook verification failed:', err.message);
      return res.status(401).json({ error: 'Unauthorized' });
    }
  }

  const event = req.body;
  const action = event?.action || event?.event || 'unknown';
  console.log(`\n🔔 Whop webhook: ${action}`);

  // Handle payment.completed
  if (action === 'payment.completed' || action === 'order.completed') {
    const order = event.data || event;
    const payload = {
      order_name:     `WHOP-${order.id || Date.now()}`,
      email:          order.user?.email || order.email || '',
      phone:          order.user?.phone_number || '',
      currency:       order.currency || 'CAD',
      total_price:    (order.final_amount / 100).toFixed(2),   // Whop uses cents
      subtotal_price: (order.subtotal / 100).toFixed(2),
      line_items: [{
        title:    order.product?.name || 'Whop Product',
        quantity: 1,
        price:    (order.final_amount / 100).toFixed(2),
        sku:      order.product?.id || '',
      }],
      shipping_lines: [],
      shipping_address: order.billing_address || {},
      billing_address:  order.billing_address || {},
      tags:   'whop-webhook',
      note:   `Whop order ${order.id} – auto-synced`,
    };

    try {
      const shopifyPayload = mapToShopifyOrder(payload);
      const shopifyRes = await fetch(`${SHOPIFY_BASE}/orders.json`, {
        method:  'POST',
        headers: SHOPIFY_HEADERS,
        body:    JSON.stringify(shopifyPayload),
      });

      if (shopifyRes.ok) {
        const data = await shopifyRes.json();
        console.log(`✅ Webhook order synced: Shopify #${data.order?.name}`);
      } else {
        console.error('❌ Shopify sync failed:', await shopifyRes.text());
      }
    } catch (err) {
      console.error('❌ Webhook processing error:', err.message);
    }
  }

  res.status(200).json({ received: true });
});

/**
 * GET /api/health
 * Health check endpoint
 */
app.get('/api/health', (req, res) => {
  res.json({
    status:  'ok',
    store:   process.env.SHOPIFY_STORE || 'not-configured',
    time:    new Date().toISOString(),
  });
});

// ─── START SERVER ─────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀 Whop-Shopify Checkout Server running on port ${PORT}`);
  console.log(`   Checkout page:     http://localhost:${PORT}`);
  console.log(`   Order sync API:    http://localhost:${PORT}/api/sync-order`);
  console.log(`   Whop webhook:      http://localhost:${PORT}/api/whop-webhook`);
  console.log(`   Health:            http://localhost:${PORT}/api/health\n`);
});
