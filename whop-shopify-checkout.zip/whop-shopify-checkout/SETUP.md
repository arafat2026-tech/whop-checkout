# 📦 Whop Shopify Checkout – Setup Guide
**Les Kicks du Québec** | Delivered by your Fiverr developer

---

## ✅ What Was Built

| Feature | Status |
|---|---|
| Shopify-identical checkout UI | ✅ Done |
| 3-step flow (Info → Shipping → Payment) | ✅ Done |
| Order summary sidebar with product image | ✅ Done |
| Discount code system | ✅ Done |
| Card / PayPal / Crypto payment tabs | ✅ Done |
| Form validation with error messages | ✅ Done |
| Mobile responsive | ✅ Done |
| Shopify Admin API order sync | ✅ Done |
| Whop webhook handler | ✅ Done |
| Order confirmation screen | ✅ Done |

---

## 📁 Project Files

```
whop-shopify-checkout/
├── index.html       ← Checkout page (Shopify-identical UI)
├── style.css        ← All styles
├── checkout.js      ← Frontend logic + order sync
├── server.js        ← Backend: Shopify API + Whop webhooks
├── package.json     ← Node.js dependencies
└── .env.example     ← Environment variables template
```

---

## 🚀 Deployment Steps

### Step 1 – Add Your API Keys

Copy `.env.example` to `.env` and fill in:

```env
SHOPIFY_STORE=les-kicks-du-quebec
SHOPIFY_ADMIN_TOKEN=shpat_XXXXXXXXXXXX
WHOP_API_KEY=your_whop_api_key
WHOP_WEBHOOK_SECRET=your_whop_webhook_secret
PORT=3000
```

### Step 2 – Get Your Shopify Admin Token

1. Go to `Admin → Settings → Apps and sales channels`
2. Click **Develop apps** → **Create an app**
3. Under **API credentials**, generate an **Admin API access token**
4. Required scopes: `write_orders`, `read_orders`, `write_customers`

### Step 3 – Install & Run the Backend

```bash
cd whop-shopify-checkout
npm install
node server.js
```

Server runs at `http://localhost:3000`

### Step 4 – Configure Whop Webhook

In your Whop dashboard:
1. Go to **Developer → Webhooks**
2. Add endpoint: `https://YOUR-DOMAIN.com/api/whop-webhook`
3. Select events: `payment.completed`, `order.completed`
4. Copy the **Webhook Secret** → paste into `.env`

### Step 5 – Host on a Server

Upload files to your hosting (Render, Railway, VPS, etc.) and update the `SYNC_ENDPOINT` in `checkout.js`:

```js
SYNC_ENDPOINT: 'https://your-domain.com/api/sync-order',
```

---

## 🔄 How the Order Sync Works

```
Customer pays on Whop Checkout Page
        ↓
checkout.js sends POST /api/sync-order
        ↓
server.js maps data → Shopify order format
        ↓
Shopify Admin API creates the order
        ↓
Customer sees confirmation screen
        ↓
Shopify sends email confirmation to customer
```

---

## 🎨 Customizing Products

Edit `checkout.js` to change the product:

```js
// Line items in buildOrderPayload()
line_items: [{
  title: 'YOUR PRODUCT NAME',
  variant_title: 'YOUR VARIANT',
  quantity: 1,
  price: '149.99',
  sku: 'YOUR-SKU',
}],
```

Update the price in `index.html`:
```html
<span class="line-item-price">CA$149.99</span>  <!-- change this -->
<span id="subtotal">CA$149.99</span>             <!-- and this -->
```

---

## 🧪 Test Discount Codes

These codes work out of the box:

| Code | Discount |
|---|---|
| `KICKS10` | 10% off |
| `SAVE20` | 20% off |
| `FREE` | CA$9.99 off |

---

## 📞 Support

If you have any questions, message me on Fiverr!
