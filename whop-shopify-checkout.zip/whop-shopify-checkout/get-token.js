/**
 * get-token.js
 * Run this once to get your Shopify access token.
 * It opens a browser, you approve, and the token is saved automatically.
 *
 * Run: node get-token.js
 */

const http     = require('http');
const https    = require('https');
const url      = require('url');
const fs       = require('fs');
const { exec } = require('child_process');

// ─── YOUR APP CREDENTIALS ────────────────────────────────────────────────────
const CLIENT_ID     = '6f82c2fa05dd39f539e795d7a4f108b7';
const CLIENT_SECRET = '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';
const SHOP          = 'les-kicks-du-quebec.myshopify.com';
const REDIRECT_URI  = 'http://localhost:3000/auth/callback';
const SCOPES        = 'write_orders,read_orders,write_customers,read_customers';
// ─────────────────────────────────────────────────────────────────────────────

const authUrl = `https://${SHOP}/admin/oauth/authorize?client_id=${CLIENT_ID}&scope=${SCOPES}&redirect_uri=${encodeURIComponent(REDIRECT_URI)}&state=secure123`;

console.log('\n🚀 Whop-Shopify Token Generator');
console.log('================================');
console.log('Opening browser for Shopify authorization...\n');

// Open browser automatically
const openBrowser = (url) => {
  const cmd = process.platform === 'win32' ? `start "" "${url}"` :
              process.platform === 'darwin' ? `open "${url}"` : `xdg-open "${url}"`;
  exec(cmd, (err) => {
    if (err) {
      console.log('⚠️  Could not open browser automatically.');
      console.log('👉 Please open this URL manually:\n');
      console.log(authUrl + '\n');
    }
  });
};

// Create a one-time local server to catch the OAuth callback
const server = http.createServer(async (req, res) => {
  const parsedUrl = url.parse(req.url, true);

  // Handle the OAuth callback
  if (parsedUrl.pathname === '/auth/callback') {
    const code  = parsedUrl.query.code;
    const state = parsedUrl.query.state;

    if (!code) {
      res.writeHead(400, { 'Content-Type': 'text/html' });
      res.end('<h2>❌ Error: No code received. Please try again.</h2>');
      return;
    }

    console.log('✅ Authorization code received! Exchanging for access token...');

    // Exchange code for token
    const postData = JSON.stringify({
      client_id:     CLIENT_ID,
      client_secret: CLIENT_SECRET,
      code:          code,
    });

    const options = {
      hostname: SHOP,
      path:     '/admin/oauth/access_token',
      method:   'POST',
      headers: {
        'Content-Type':   'application/json',
        'Content-Length': Buffer.byteLength(postData),
      },
    };

    const tokenReq = https.request(options, (tokenRes) => {
      let data = '';
      tokenRes.on('data', chunk => data += chunk);
      tokenRes.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          const token  = parsed.access_token;

          if (!token) {
            console.error('❌ Failed to get token:', data);
            res.writeHead(500, { 'Content-Type': 'text/html' });
            res.end(`<h2>❌ Token exchange failed.</h2><pre>${data}</pre>`);
            return;
          }

          console.log('\n🎉 SUCCESS! Access token received!\n');
          console.log('Token: ' + token);

          // Save token to .env file
          let envContent = '';
          if (fs.existsSync('.env')) {
            envContent = fs.readFileSync('.env', 'utf8');
            // Replace or add SHOPIFY_ADMIN_TOKEN
            if (envContent.includes('SHOPIFY_ADMIN_TOKEN=')) {
              envContent = envContent.replace(
                /SHOPIFY_ADMIN_TOKEN=.*/,
                `SHOPIFY_ADMIN_TOKEN=${token}`
              );
            } else {
              envContent += `\nSHOPIFY_ADMIN_TOKEN=${token}`;
            }
          } else {
            envContent = `SHOPIFY_STORE=les-kicks-du-quebec\nSHOPIFY_ADMIN_TOKEN=${token}\nWHOP_API_KEY=\nWHOP_WEBHOOK_SECRET=\nPORT=3000\n`;
          }

          fs.writeFileSync('.env', envContent);
          console.log('\n✅ Token saved to .env file!\n');

          // Show success page in browser
          res.writeHead(200, { 'Content-Type': 'text/html' });
          res.end(`
            <!DOCTYPE html>
            <html>
            <head>
              <title>Token Saved!</title>
              <style>
                body { font-family: Arial, sans-serif; text-align: center; padding: 60px; background: #f0fdf4; }
                .box { background: white; border-radius: 12px; padding: 40px; max-width: 500px; margin: 0 auto; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
                h1 { color: #16a34a; font-size: 2rem; }
                code { background: #f1f5f9; padding: 10px 20px; border-radius: 6px; display: block; word-break: break-all; font-size: 13px; margin: 16px 0; }
                p { color: #555; }
              </style>
            </head>
            <body>
              <div class="box">
                <h1>🎉 Token Saved!</h1>
                <p>Your Shopify access token has been saved to <strong>.env</strong></p>
                <code>${token}</code>
                <p>You can now close this window and go back to the terminal.</p>
              </div>
            </body>
            </html>
          `);

          // Close server after 3 seconds
          setTimeout(() => {
            console.log('✅ Done! You can now run: node server.js\n');
            server.close();
            process.exit(0);
          }, 3000);

        } catch (e) {
          console.error('❌ Parse error:', e.message);
          res.writeHead(500, { 'Content-Type': 'text/html' });
          res.end('<h2>❌ Error parsing response.</h2>');
        }
      });
    });

    tokenReq.on('error', (e) => {
      console.error('❌ Request error:', e.message);
      res.writeHead(500, { 'Content-Type': 'text/html' });
      res.end('<h2>❌ Request failed. Check your internet connection.</h2>');
    });

    tokenReq.write(postData);
    tokenReq.end();
    return;
  }

  // Root page
  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end(`<h2>Waiting for Shopify authorization...</h2><p><a href="${authUrl}">Click here if browser didn't open</a></p>`);
});

server.listen(3000, () => {
  console.log('🔒 Local auth server running on http://localhost:3000');
  console.log('📂 Waiting for Shopify to redirect back...\n');
  openBrowser(authUrl);
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error('❌ Port 3000 is already in use. Close other apps and try again.');
  } else {
    console.error('❌ Server error:', err.message);
  }
  process.exit(1);
});
